#define main()
#read text.txt file and split it
#create unique_words
#call main

def main():
    filename= input("Enter the name of the file:")
    openfile= open(filename,'r')
    read_line= openfile.readlines()
    new=[]
    for l in read_line:
        new=new+l.split()
    unique_words=[]
    for x in new:
        if x not in unique_words:
            unique_words.append(x)
    for y in unique_words:
        print(y)
    print("End of list")

main()
        
