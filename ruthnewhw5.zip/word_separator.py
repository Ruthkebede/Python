#define main
#input a sentence with first character of each word being uppercase
#introduce a for loop to specify where the space should go in between the words
#print results and call main

def main():
    result=''
    sentence= input('Enter a string: ')

    result=result + sentence[0]

    for i in range(1,len(sentence)):
        y= sentence[i]
        if y.isupper():
            y=y.lower()
            result =result+' '
            
        result=result+y
       

    print(result)
main()
