#define main
#read text.txt file and use for loop to determine the uppercase, lowercase,digit and space
#print results and call main()


def main():
    file= open('text.txt','r')
    upper,lower,digit,space=0,0,0,0

    for line in file:
        for x in line:
            if x.isupper():
                upper= upper+1
            elif x.islower():
                lower=lower+1
            elif x.isdigit():
                digit=digit+1
            elif x is ' ':
                space=space+1


    print('Uppercase letters: '+ str(upper))
    print('Lowercase letters: '+ str(lower))
    print('Digits: '+ str(digit))
    print('Spaces: '+str(space))

main()
