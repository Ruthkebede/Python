#define main and input the first and second text file
#make for loop then find union
#then find intersection and differences between set1 and set 2
#then find sym_diff then call main

def main(filename):
    words=[]
    with open (filename,'r') as file:
        for line in file:
            for word in line.split():
                words.append(word)
    
    return words

filename1= input ("Enter the name of the First input file: ")

words1= main(filename1)
set1= set(words1)
filename2= input("Enter the name of the Second input file : ")
words2= main(filename2)
set2= set(words2)

print('\nThese are the unique words that are contained in both files:')
wordstogether=words1+words2
wordstogether=set(wordstogether)
print(wordstogether,'\n')

print('These are the words that appear both files')
intersection= set1.intersection(set2)
print(intersection,'\n')

print('These are the words that appear in the first file but do not appear in the second file:')
difference1= set1-set2
print(difference1,'\n')

print('These are the words that appear in the second file but do not appear in the first file:')
difference2=set2-set1
print(difference2,'\n')

print('These are the words that appear in the first file or the second file but do not appear in the both files:')
sym_diff=set1.symmetric_difference(set2)
print(sym_diff,'\n')


main
