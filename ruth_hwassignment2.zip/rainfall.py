
#Input number of years then specify the range
#Tn the for loop, ask the monthly rain amount
#Then get the total number of months and total inches ot rain.
#Display the average rainfall and total rainfall using the formaulas.



tot_num_of_months =0
tot_inches_of_rain=0


number_of_years=int(input("Enter the number of years: "))
for current_year in range(1,number_of_years + 1):
    print("For year",current_year,":")
    for current_month in range(1,13):
        month_rain_amount=float(input("Enter the rainfall amount for the month: "))
        tot_inches_of_rain +=month_rain_amount
        tot_num_of_months += 1

average_rainfall= tot_inches_of_rain/tot_num_of_months
print("For ",tot_num_of_months,"months")
print("Total rainfall: " + format(tot_inches_of_rain,".2f"),"inches" 
    "\nAverage monthly rainfall: " + format(average_rainfall,".2f"),"inches" )

        

