
#Enter budgeted amount.
#Record Expenses and give the user the chance to put additional cost.
#On the While loop get total expense.
#Use the total expence and compare if it is more or less than budget.
#If more under budget, if less over budget.


budgeted = float(input("Enter budget amount: "))
additional_expenses= "y"
total_expenses=0

while additional_expenses == "y":
    spent=float(input("Enter your expense: "))
    total_expenses += spent
    additional_expenses=input("do you have more expenses?: Type y"+ " for yes, type any key for no: ")

print("Budgeted:$", format(budgeted,".2f"))
print("Spent:$", format(spent,".2f"))

if budgeted > total_expenses:
    print("You are $",format(budgeted - total_expenses,".2f"),"under budget. WELL DONE!", )


elif total_expenses > budgeted:
    print("You are $" + format(total_expenses - budgeted,".2f"),"under budget. WELL DONE!")

else:
    print("You used exactly your budget amount "+ format(budgeted,".2f"))
