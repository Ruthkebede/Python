#write a class called Employee and list the attributes
#define each attribute for 3 different users
#display each users information


class Employee():
    emplo_name=''
    id_num=''
    emplo_dept=''
    emplo_job_title=''

emplo_obj1=Employee()
emplo_obj1.emplo_name='Susan Meyers'
emplo_obj1.id_num='47899'
emplo_obj1.emplo_dept=' Accounting'
emplo_obj1.emplo_job_title=' Vice President'

emplo_obj2=Employee()
emplo_obj2.emplo_name='Mark Jones'
emplo_obj2.id_num='39119'
emplo_obj2.emplo_dept=' IT'
emplo_obj2.emplo_job_title='Programmer'

emplo_obj3=Employee()
emplo_obj3.emplo_name='Joy Rogers'
emplo_obj3.id_num='81774'
emplo_obj3.emplo_dept='Manufacturing'
emplo_obj3.emplo_job_title='Engineer'

print('Employee 1:')
print('Name:',emplo_obj1.emplo_name)
print('ID number:',emplo_obj1.id_num)
print('Department:',emplo_obj1.emplo_dept)
print('Title:',emplo_obj1.emplo_job_title)
print()

print('Employee 2:')
print('Name:',emplo_obj2.emplo_name)
print('ID number:',emplo_obj2.id_num)
print('Department:',emplo_obj2.emplo_dept)
print('Title:',emplo_obj2.emplo_job_title)
print()

print('Employee 3:')
print('Name:',emplo_obj3.emplo_name)
print('ID number:',emplo_obj3.id_num)
print('Department:',emplo_obj3.emplo_dept)
print('Title:',emplo_obj3.emplo_job_title)
print()
