
#create a class called Person and write data attributes
#write a class called Customer which is a subclassand define data attributes
#create a boolean data attribute for mailling list
#define main so the user can enter data then print result
#finally call main



class Person:
    def __init__(self,name,tel_num,address):
        self.__name=name
        self.__tel_num=tel_num
        self.__address=address
    

    def set_name(self,name):
        self.__name=name

    def set_tel_num(self,tel_num):
        self.__tel_num=tel_num

    def set_address(self,address):
        self.__address=address

    def get_name(self):
        return self.__name   
    
    def get_tel_num(self):
        return self.__tel_num
    
    def get_address(self):
        return self.__address 

class Customer(Person):
    def __init__(self,name,tel_num,address,cus_num,mail):
        Person.__init__(self,name,tel_num,address)
        self.__cus_num=cus_num
        self.__mail=mail


    def set_cus_num(self,cus_num):
        self.__cus_num

    def set_mail(self,mail):
        self.__mail=mail
        
    def __bool__(self):
        if self.__mail== "yes":
            return True
        elif self.__mail=="no":
            return False
        
    def get_cus_num(self):
        return self.__cus_num

    def get_mail(self):
        return self.__mail
    

def main():
    name=input("Enter the name: ")
    address=input("Enter the address:")
    number=int(input("Enter phone_number:"))
    cus_num=(input("Enter the customer number"))
    mail=bool(input("Does the customer wish to be on the mailing list?(Yes/No):"))
    

    cust=Customer(name,number,address,cus_num,mail)

    print("Customer information:")
    print("Name:",cust.get_name())
    print("Address:",cust.get_address())
    print("Phone number:",cust.get_tel_num())
    print("Customer Number:",cust.get_cus_num())
    print("On Mailing List:",cust.get_mail())

main()
