#input money
#show that the integer part is the amount of dollar bills
#find cents then multiply by 100 to perform further division.
#divide by 25 for quarters, then divide by 10 for dimes, then divide by 5 for nickes and the rest is pennies.

money=float(input("enter an amount: "))
print("Your amount",money,"consists of: ")
one_dollars=int(money)
print(one_dollars,"dollars")
cents=money-one_dollars
quarters=round(cents*100,2)
print(int(quarters/25),"quarters")
dimes=(int(quarters%25))
print(int(dimes/10),"dimes")
nickels=(int(dimes%10))
print(int(nickels/5),"nickels")
pennies=(int(nickels%5))
print(pennies,"pennies")

