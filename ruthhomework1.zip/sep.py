
#Input monthly pay
#Multiple monthly pay by 12 to find annual pay
#Use sep to show $

monthly_pay= float(input("enter monthly pay: "))
annual_pay=monthly_pay*12
print('The annual pay is: ',format(annual_pay,'.2f'),sep='$')
