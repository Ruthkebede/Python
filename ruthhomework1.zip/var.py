#input square feet
#convert square feet to acre
#print acre in 2 decimal points.

sq_ft_to_acre=43560
square_feet=float(input("enter square feet in track: "))
the_acre=square_feet/sq_ft_to_acre
print("The size of that track is %.2f acres" %(the_acre))
