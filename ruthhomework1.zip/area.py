#First insert radius
#Then write formula of area of a circle.
#Print statment to show when radius is an int the area should have 5 decimal points.
#Print statment to show when radius has 2 decimal points the area should also have 2 decimal points.

radius=0.0
area=0.0
radius=float(input("enter radius:"))
area= radius*radius*3.14159
print("The area for the circle of radius %.0f is %.5f"%(radius,area))
print("The area for the circle of radius %.2f is %.2f" %(radius,area))
