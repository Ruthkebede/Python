
#Define calories from fat and calories of carbs by using the given formula
#Create a function main, to as the user to enter the fat grams and carb grams
#Calculate calories from fat and calories from carbs
#Print grams of fat, fat calories, gram of carbs, carb calories in order



def findcaloriesfromfat(fatgrams):
    caloriesfromfat=fatgrams*9
    return caloriesfromfat
def findcaloriesfromcarbs(carbgrams):
    caloriesfromcarbs=carbgrams*4
    return caloriesfromcarbs

def main():
    user_fatgrams=float(input("Enter fat grams"))
    user_carbgrams=float(input("Enter carb grams"))
    caloriesfromfat=findcaloriesfromfat(user_fatgrams)
    caloriesfromcarbs=findcaloriesfromcarbs(user_carbgrams)
    print()
    print("If fat grams consumed entered is ", user_fatgrams)
    print("If carbohydrate grams consumed entered is" ,user_carbgrams, "then the output would be: ")
    print("Gram of fat: " + format (user_fatgrams, ".2f"))
    print("Fat Calories:" + format(caloriesfromfat, ".2f"))
    print("Grams of carbs:" + format(user_carbgrams, ".2f"))
    print("Carb calories: " + format(caloriesfromcarbs, ".2f"))

main()
