
#Import random so the system can chose two numbers to use with in the range provided.
#Print (num1,num2) and ask user to provide answer to the question.
#If correct say congratulations. If not provide the answer. finally define name and call it.

import random
randomnum1=random.randint(0,900)
randomnum2=random.randint(0,900)

def question():
    global randomnum1
    global randomnum2
    print(randomnum1,"\n","+", randomnum2)
    user_answer= int(input("Enter sum of numbers:" + str(randomnum1) +  "+"  + str(randomnum2)+ ": "))
    return user_answer

def checkanswer(user_answer):
    global randomnum1
    global randomnum2
    
    finalanswer= randomnum1 + randomnum2
    print()
    if user_answer==finalanswer:
        print("CONGRATULATIONS")
    else:
        print("Incorrect... The correct answer is:", finalanswer)

def main():
    user_answer= question()
    checkanswer(user_answer)
    
main()
